class Student:
    def __init__(self, name, age, subjects):
        self.name = name
        self.age = age
        self.subjects = subjects

    def add_subject(self, subject):
        self.subjects.append(subject)

    def get_info(self):
        return f"{self.name} is {self.age} and studies: {', '.join(self.subjects)}"


students = []

alice = Student("Alice", 15, ["Math", "Science"])
students.append(alice)

jako = Student("jako", 17, ["istoria", "astronomia"])
students.append(jako)

lasa = Student("lasa", 17, ["enebi"])
students.append(lasa)

beso = Student("beso", 17, ["geografia", "astronomia"])
students.append(beso)

print("სტუდენტების რაოდენობა:", len(students))


r = input("ვისი ამოშლა გინდათ სიიდან: ")
remove = r
students = [s for s in students if s.name != remove]
print(f"{remove} წაიშალა სიიდან.")
print("ახლანდელი სტუდენტები:", [s.name for s in students])


nisani = {
    "Alice": 90,
    "jako": 85,
    "beso": 88,
    "lasa": 70
}

a = input("ვისი ნიშანი გინდა შეცვალოთ: ")
b = int(input("რამდენით (შეიყვანე ახალი ნიშანი): "))

if a in nisani:
    nisani[a] = b
    print(f"განახლებული {a}-ის ნიშანი: {nisani[a]}")
else:
    print("მასეთი მოსწავლე არ მოიძებნება")

print("\nსტუდენტების ნიშნები:")
for name, grade in nisani.items():
    print(f"{name} = {grade} ქულა")



schedule = ("Math", "Lunch", "Science", "Gym")

print("სიდან მეორე:", schedule[1])

try:
    schedule[1] = "Break"
except TypeError as e:
    print("შეცდომა ტუპლის შეცვლისას:", e)


classes = {"Robotics", "Debate", "Art"}
classes.add("Music")
classes.add("Art")  
print("გაკვეთილების სვეტი", classes)
check_class = "Debate"
if check_class in classes:
    print(f"{check_class} არის სეტში.")
else:
    print(f"{check_class} არ არის სეტში.")

morning_classes = {"Math", "Science", "Robotics"}
afternoon_classes = {"Art", "Science", "Music", "Robotics"}

common = morning_classes & afternoon_classes
print("\nსაერთო გაკვეთილები დილის და დღის ჯგუფებს შორის:", common)

